from django.shortcuts import render,HttpResponseRedirect,HttpResponse,redirect
from .models import Product,Categories,Customer,Order
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
from .middlewares import auth_middleware
from  django.utils.decorators import method_decorator


class Home(View):
    def get(self,request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        cate = Categories.get_all_categories()
        categoryID = request.GET.get('category')
        if categoryID:
            products =Product.get_all_product_by_category_id(categoryID)
            context = {'products':products, 'categories': cate} 
        else:
            products = Product.get_all_product()
            context = {'products':products, 'categories': cate}
            
        return render(request,'store/home.html', context)
    def post(self,request):
        product = request.POST.get("product")
        remove = request.POST.get("remove")
        cart = request.session.get('cart')

        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <=1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1

        else:
            cart = {}
            cart[product] = 1
        
        request.session['cart'] = cart
        return redirect('homepage')


class SignUp(View):
    def get(self,request):
        return render(request,'store/signup.html')
    def post(self,request):
        return self.isrequestPostSignup(request)

        
    def validateCustomerSignup(self,customer):
            error_message = None

            if not customer.first_name:
                error_message = "First Name is required !!"
            elif len(customer.first_name) < 3:
                error_message = "First Name should be Greter than 3 character !!"
            elif not customer.last_name:
                error_message = "Last Name is required !!"
            elif len(customer.last_name) < 3:
                error_message = "Last Name should be Greter than 3 character !!"
            elif not customer.phone:
                error_message = "Phone Number is required !!"
            elif len(customer.phone) < 10:
                error_message = "Phone Number should be Greter than 9 digit !!"
            elif not customer.email:
                error_message = "Email is required !!"
            elif len(customer.email)<10:
                error_message = "Email should be Greter than 9 character !!"
            elif customer.isExist():
                error_message = "Email alredy registerd  !!"
            
            return error_message
        
    def isrequestPostSignup(self,request):
            postdata = request.POST
            first_name = postdata.get('firstname')
            last_name = postdata.get('lastname')
            phone = postdata.get('phone')
            email = postdata.get('email')
            password = postdata.get('password')
            
            customer = Customer(first_name=first_name, last_name = last_name , phone=phone, email=email ,password = password)
            value = {'first_name':first_name, 'last_name':last_name,'phone':phone, 'email':email}
            
            error_message = self.validateCustomerSignup(customer)
            if not error_message:
                customer.password = make_password(password)
                customer.register()
                return redirect('homepage')
            else:
                context = {'values':value, 'error':error_message}
                return render(request,'store/signup.html',context)



class Login(View):
    return_url = None
    def get(self,request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'store/login.html')
    def post(self,request):
        data = request.POST
        email = data.get('email')
        password = data.get('password')
        error_message = None

        customer = Customer.get_custome_by_email(email)
        if customer:
            if check_password(password, customer.password):
                request.session['customer'] = customer.id
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('homepage')
            else:
                error_message = "Enter currect password to login "
                        
        else:
            error_message = "Email  or Password Invalid " 
        return render(request,'store/login.html',{'email':email , 'error':error_message})
 

def user_logout(request):
    request.session.clear()
    return redirect("login")
        
            

class Cart(View):
    def get(self, request):
        ids = request.session.get('cart').keys()
        products = Product.get_all_product_by_ids(ids)

        return render(request,'store/cart.html',{'products':products})     

        

class CheckOut(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_all_product_by_ids(list(cart.keys()))

        
        for product in products:
            order = Order(
                        product = product,
                         customer=Customer(id=customer),
                         address = address,
                         phone = phone,
                         price = product.price,
                         quantity =cart.get(str(product.id))
                        )
            order.PlaceOrder()
        request.session['cart'] ={}

        return  redirect('cart')



class UserOrder(View):

    @method_decorator(auth_middleware)
    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_all_order(customer)

        return render(request,'store/order.html' , {'orders':orders})
# def user_sign_up(request):
#     if request.method == 'POST':
#         fm = signupForm(request.POST)
#         if fm.is_valid():
#             fm.save()
#     else:
#         fm = signupForm()
#     return render(request, 'store/signup.html', {'form':fm})

# def user_login(request):
#     if not request.user.is_authenticated:
#         if request.method == "POST":
#             fm = LoginForm(request=request, data =request.POST)
#             if fm.is_valid():
#                 uname  = fm.cleaned_data['username']
#                 upass = fm.cleaned_data['password']
#                 user = authenticate(username=uname, password=upass)
#                 if user is not None:
#                     login(request, user)
#                     messages.success(request,"You Logged Successfully")
#                     return HttpResponseRedirect('/')

#         else:
#             fm = LoginForm()
#         return render(request, 'store/login.html',{"form":fm})
#     else:
#         return HttpResponseRedirect('/')
    
# def user_logout(request):
#     if request.user.is_authenticated:
#         logout(request)
#         return HttpResponseRedirect('/')
#     else:
#         return HttpResponseRedirect('/')



