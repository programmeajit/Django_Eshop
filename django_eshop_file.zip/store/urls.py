from django.urls import path
from . import views
urlpatterns =[
    path('',views.Home.as_view(),name='homepage'),
    path('signup/', views.SignUp.as_view(), name='signup'),
    path('login/', views.Login.as_view(), name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('cart/', views.Cart.as_view(), name='cart'),
    path('checkout/', views.CheckOut.as_view(), name='checkout'),
    path('order/', views.UserOrder.as_view(), name='order'),
]